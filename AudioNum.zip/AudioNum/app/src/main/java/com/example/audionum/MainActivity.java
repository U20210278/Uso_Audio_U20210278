package com.example.audionum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ImageButton uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,diez;
    Button siguiente;

    private HashMap<Integer, MediaPlayer> mediaPlayerMap;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializar el HashMap
        mediaPlayerMap = new HashMap<>();
        // Agregar los MediaPlayer al HashMap
        mediaPlayerMap.put(R.id.Iuno, MediaPlayer.create(this, R.raw.uno));
        mediaPlayerMap.put(R.id.Idos, MediaPlayer.create(this, R.raw.dos));
        mediaPlayerMap.put(R.id.Itres, MediaPlayer.create(this, R.raw.tres));
        mediaPlayerMap.put(R.id.Icuatro, MediaPlayer.create(this, R.raw.cuatro));
        mediaPlayerMap.put(R.id.Icinco, MediaPlayer.create(this, R.raw.cinco));
        mediaPlayerMap.put(R.id.Iseis, MediaPlayer.create(this, R.raw.seis));
        mediaPlayerMap.put(R.id.Isiete, MediaPlayer.create(this, R.raw.siete));
        mediaPlayerMap.put(R.id.Iocho, MediaPlayer.create(this, R.raw.ocho));
        mediaPlayerMap.put(R.id.Inueve, MediaPlayer.create(this, R.raw.nueve));
        mediaPlayerMap.put(R.id.Idiez, MediaPlayer.create(this, R.raw.diez));

        // Encontrar los botones por su ID
        uno = findViewById(R.id.Iuno);
        dos = findViewById(R.id.Idos);
        tres = findViewById(R.id.Itres);
        cuatro = findViewById(R.id.Icuatro);
        cinco = findViewById(R.id.Icinco);
        seis = findViewById(R.id.Iseis);
        siete = findViewById(R.id.Isiete);
        ocho = findViewById(R.id.Iocho);
        nueve = findViewById(R.id.Inueve);
        diez = findViewById(R.id.Idiez);
        siguiente = findViewById(R.id.next);

        // Establecer el OnClickListener para los botones
        uno.setOnClickListener(this);
        dos.setOnClickListener(this);
        tres.setOnClickListener(this);
        cuatro.setOnClickListener(this);
        cinco.setOnClickListener(this);
        seis.setOnClickListener(this);
        siete.setOnClickListener(this);
        ocho.setOnClickListener(this);
        nueve.setOnClickListener(this);
        diez.setOnClickListener(this);
        siguiente.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        // Verificar si el botón presionado está en el HashMap
        if (mediaPlayerMap.containsKey(v.getId())) {
            // Reproducir el sonido asociado al botón
            MediaPlayer mediaPlayer = mediaPlayerMap.get(v.getId());
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        } else if (v.getId() == R.id.next) {
            // Crea un Intent para abrir la nueva actividad
            Intent intent = new Intent(MainActivity.this, MainIngles.class);
            // Inicia la nueva actividad
            startActivity(intent);


        }
    }
}
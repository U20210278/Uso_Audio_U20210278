package com.example.audionum;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import java.util.HashMap;

public class MainIngles extends AppCompatActivity implements View.OnClickListener  {

    ImageButton uno,dos,tres,cuatro,cinco,seis,siete,ocho,nueve,diez;


    private HashMap<Integer, MediaPlayer> mediaPlayerMap;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ingles);

        // Inicializar el HashMap
        mediaPlayerMap = new HashMap<>();
        // Agregar los MediaPlayer al HashMap
        mediaPlayerMap.put(R.id.Iuno, MediaPlayer.create(this, R.raw.one));
        mediaPlayerMap.put(R.id.Idos, MediaPlayer.create(this, R.raw.two));
        mediaPlayerMap.put(R.id.Itres, MediaPlayer.create(this, R.raw.three));
        mediaPlayerMap.put(R.id.Icuatro, MediaPlayer.create(this, R.raw.four));
        mediaPlayerMap.put(R.id.Icinco, MediaPlayer.create(this, R.raw.five));
        mediaPlayerMap.put(R.id.Iseis, MediaPlayer.create(this, R.raw.six));
        mediaPlayerMap.put(R.id.Isiete, MediaPlayer.create(this, R.raw.seven));
        mediaPlayerMap.put(R.id.Iocho, MediaPlayer.create(this, R.raw.eight));
        mediaPlayerMap.put(R.id.Inueve, MediaPlayer.create(this, R.raw.nine));
        mediaPlayerMap.put(R.id.Idiez, MediaPlayer.create(this, R.raw.ten));

        // Encontrar los botones por su ID
        uno = findViewById(R.id.Iuno);
        dos = findViewById(R.id.Idos);
        tres = findViewById(R.id.Itres);
        cuatro = findViewById(R.id.Icuatro);
        cinco = findViewById(R.id.Icinco);
        seis = findViewById(R.id.Iseis);
        siete = findViewById(R.id.Isiete);
        ocho = findViewById(R.id.Iocho);
        nueve = findViewById(R.id.Inueve);
        diez = findViewById(R.id.Idiez);


        // Establecer el OnClickListener para los botones
        uno.setOnClickListener(this);
        dos.setOnClickListener(this);
        tres.setOnClickListener(this);
        cuatro.setOnClickListener(this);
        cinco.setOnClickListener(this);
        seis.setOnClickListener(this);
        siete.setOnClickListener(this);
        ocho.setOnClickListener(this);
        nueve.setOnClickListener(this);
        diez.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        // Verificar si el botón presionado está en el HashMap
        if (mediaPlayerMap.containsKey(v.getId())) {
            // Reproducir el sonido asociado al botón
            MediaPlayer mediaPlayer = mediaPlayerMap.get(v.getId());
            if (mediaPlayer != null) {
                mediaPlayer.start();
            }
        }
    }
}